package com.example.gestionale.exceptions;

public class CredenzialiNonValide extends RuntimeException {
    public CredenzialiNonValide(String message) {
        super(message);
    }
}
