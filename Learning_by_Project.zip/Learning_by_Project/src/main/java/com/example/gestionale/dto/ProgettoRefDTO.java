package com.example.gestionale.dto;

import com.example.gestionale.models.Progetto;

public class ProgettoRefDTO {
    private Long idProgetto;
    private String nome;
    private String stato;

    public ProgettoRefDTO() {
    }

    public static ProgettoRefDTO fromEntity(Progetto p) {
        if (p == null) return null;
        ProgettoRefDTO dto = new ProgettoRefDTO();
        dto.idProgetto = p.getIdProgetto();
        dto.nome = p.getNome();
        dto.stato = p.getStato();
        return dto;
    }

    public Long getIdProgetto() {return idProgetto;}
    public void setIdProgetto(Long idProgetto) {this.idProgetto = idProgetto;}
    public String getNome() {return nome;}
    public void setNome(String nome) {this.nome = nome;}
    public String getStato() {return stato;}
    public void setStato(String stato) {this.stato = stato;}
}
