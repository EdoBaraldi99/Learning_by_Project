# Backend changelog

Documentazione delle modifiche fatte al backend Spring Boot (`com.example.gestionale`) durante la sessione di lavoro corrente. Copre due interventi distinti, entrambi ancora da propagare in un eventuale ambiente diverso da quello locale (vedi [Migrazione database](#migrazione-database-da-riapplicare-su-ogni-nuovo-ambiente) in fondo).

1. [Risposte API annidate](#1-risposte-api-annidate-invece-di-id-piatti) — i DTO di lettura restituivano solo ID grezzi, il frontend si aspettava oggetti annidati.
2. [Login e ruoli](#2-login-e-ruoli-isadmin--associatoruolo) — nuovo endpoint di autenticazione e flag di amministratore.

---

## 1. Risposte API annidate invece di ID piatti

### Perché

`GET /attivita/lista`, `GET /progetti/{id}`, `GET /storici/lista`, `GET /assegnati`, `GET /associati` restituivano solo liste di ID (`assegnatiIds`, `associatiIds`, `attivitaIds`, `storicoIds`) invece degli oggetti annidati (dipendente assegnato, progetto, task). Tutto il frontend era scritto assumendo la forma annidata: il risultato era che liste di task, avatar dei colleghi, avanzamento progetti ecc. apparivano sempre vuoti, senza errori visibili.

### Nuovi DTO di riferimento (leggeri, nessuna dipendenza circolare)

| File | Campi | Scopo |
|---|---|---|
| `dto/ProgettoRefDTO.java` | `idProgetto, nome, stato` | riferimento leggero a un progetto, usato dentro `AttivitaResponseDTO` e `AttivitaRefDTO` |
| `dto/DipendenteRefDTO.java` | `idDipendente, nome, cognome, area` | riferimento leggero a un dipendente, usato dentro `AssegnatoResponseDTO` e `AssociatoResponseDTO` |
| `dto/AttivitaRefDTO.java` | `idTask, titolo, tipologia, progetto: ProgettoRefDTO` | riferimento leggero a un task, usato dentro `StoricoResponseDTO` |

Questi DTO "Ref" esistono per evitare cicli infiniti di serializzazione (es. `Progetto → Attivita → Progetto → ...`): annidano solo dati scalari, mai un'altra collezione.

### DTO modificati

**`dto/AttivitaResponseDTO.java`**
- Rimossi: `idProgetto` (Long), `nomeProgetto` (String), `storicoIds` (List\<Long\>), `assegnatiIds` (List\<Long\>)
- Aggiunti: `progetto: ProgettoRefDTO`, `storico: List<StoricoResponseDTO>`, `assegnati: List<AssegnatoResponseDTO>`

**`dto/ProgettoResponseDTO.java`**
- Rimossi: `attivitaIds` (List\<Long\>), `associatiIds` (List\<Long\>)
- Aggiunti: `attivita: List<AttivitaResponseDTO>`, `associati: List<AssociatoResponseDTO>`

**`dto/StoricoResponseDTO.java`**
- Rimossi: `idTask` (Long), `titoloTask` (String)
- Aggiunto: `attivita: AttivitaRefDTO`

**`dto/AssegnatoResponseDTO.java`**
- Rimossi: `idDipendente`, `nomeDipendente`, `cognomeDipendente` (flat), `idAttivita`, `titoloAttivita` (mai usati da nessun consumer, rimossi per evitare un riferimento circolare inutile)
- Aggiunto: `dipendente: DipendenteRefDTO`

**`dto/AssociatoResponseDTO.java`**
- Rimossi: `idDipendente`, `nomeDipendente`, `cognomeDipendente`, `idProgetto`, `nomeProgetto` (flat)
- Aggiunti: `dipendente: DipendenteRefDTO`, `progetto: ProgettoRefDTO`
- Campo `ruolo` (String) invariato

Nessun controller è stato toccato: gli URL e i verbi HTTP restano identici, cambia solo il corpo delle risposte GET.

### Esempio — `GET /attivita/1` prima/dopo

Prima:
```json
{ "idTask": 1, "titolo": "...", "idProgetto": 3, "nomeProgetto": "...", "assegnatiIds": [1], "storicoIds": [1,2,3] }
```

Dopo:
```json
{
  "idTask": 1, "titolo": "...",
  "progetto": { "idProgetto": 3, "nome": "...", "stato": "in corso" },
  "assegnati": [{ "idDipendenteAssegnaTask": 1, "ruolo": "sviluppatore", "dipendente": { "idDipendente": 1, "nome": "Giorgio", "cognome": "Merco", "area": "sistemi" } }],
  "storico": [{ "idStorico": 1, "data": "...", "tempoLavorato": "5 ore", "attivita": { "idTask": 1, "titolo": "...", "tipologia": "sviluppo", "progetto": { "idProgetto": 3, "nome": "...", "stato": "in corso" } } }]
}
```

`DipendenteResponseDTO` **non** è stato toccato in questo intervento (nessun consumer leggeva `assegnatiIds`/`associatiIds` da lì); resta con gli ID piatti, innocui perché inutilizzati.

---

## 2. Login e ruoli (`isAdmin` + `Associato.ruolo`)

### Perché

Introdotta l'autenticazione (email + password) e una vista differenziata per ruolo: un dipendente con `isAdmin = true` ha accesso completo; altrimenti il suo ruolo effettivo dipende da `Associato.ruolo` **per singolo progetto** (`Employee` = sola lettura, qualsiasi altro valore = può gestire i task di quel progetto).

### Nuovo campo su `Dipendente`

**`models/Dipendente.java`**
```java
@Column(name = "is_admin")
public Boolean isAdmin;
// + getIsAdmin() / setIsAdmin(Boolean)
```
Colonna nullable, creata automaticamente da Hibernate (`ddl-auto=update`). Trattata come `false` quando `null` (vedi sotto).

**`dto/DipendenteResponseDTO.java`**: aggiunto `isAdmin` (sempre restituito come `true`/`false`, mai `null`, tramite `d.getIsAdmin() != null && d.getIsAdmin()`).

**`dto/DipendenteRequestDTO.java`**: aggiunto `isAdmin`. In `toEntity()` viene sempre normalizzato a `false` se non specificato (usato da `POST /dipendenti/crea`). In `modificaDipendentePerId` (`services/DipendenteService.java`) viene applicato solo se presente nel payload, stesso pattern degli altri campi opzionali.

### Nuovo endpoint di login

**`dto/LoginRequestDTO.java`** (nuovo file): `{ email: String, password: String }`.

**`controllers/AuthController.java`** (nuovo file):
```
POST /auth/login
Body:    { "email": "...", "password": "..." }
200 OK:  DipendenteResponseDTO (incluso isAdmin)
401:     { "errore": "Unauthorized", "messaggio": "Email o password non corretti", ... }
```

**`services/DipendenteService.java`**: nuovo metodo `login(LoginRequestDTO)` — cerca il dipendente per email con `DipendenteRepository.findDipendenteByEmail` (query già esistente, non modificata), confronta la password **in chiaro** (nessun hashing: coerente con lo stato attuale della colonna `password`, che è già testo semplice — cambiamento rimandato di proposito, va rivisto prima di un eventuale uso in produzione), lancia `CredenzialiNonValide` se l'email non esiste o la password non combacia.

**`exceptions/CredenzialiNonValide.java`** (nuovo file, `RuntimeException`, stesso pattern di `EntitaNonTrovata`).

**`exceptions/GlobalExceptionHandler.java`**: nuovo `@ExceptionHandler(CredenzialiNonValide.class)` → risponde `401 UNAUTHORIZED` con lo stesso formato `Errore` già usato per gli altri casi (404/400/409/500).

### Nessuna vera autorizzazione lato server

Importante: questo intervento aggiunge solo l'endpoint di login e il dato `isAdmin`/`ruolo` da cui il frontend deriva cosa mostrare. **Nessun controller CRUD è stato protetto**: `POST/PATCH/DELETE` su `/attivita`, `/progetti`, `/dipendenti`, `/assegnati`, `/associati` restano raggiungibili da chiunque conosca l'URL, indipendentemente da chi ha fatto login (non esiste un concetto di sessione/token lato server). Il controllo dei permessi oggi è **solo lato frontend** (bottoni nascosti/mostrati in base al ruolo). Da tenere presente prima di esporre questo backend fuori da un ambiente di sviluppo fidato.

---

## Migrazione database (da riapplicare su ogni nuovo ambiente)

Il file di export dello schema (`db_sottointesi (1).sql`) **non riflette** queste modifiche. Su un database creato da quel dump, o su qualunque copia diversa da quella usata in questa sessione, vanno riapplicati:

```sql
-- 1) Colonna isAdmin (se non già creata automaticamente da Hibernate al primo avvio con ddl-auto=update)
ALTER TABLE dipendente ADD COLUMN is_admin BIT(1) NULL;

-- 2) Impostare almeno un amministratore (sostituire l'ID)
UPDATE dipendente SET is_admin = 0 WHERE is_admin IS NULL;
UPDATE dipendente SET is_admin = 1 WHERE id_dipendente = 1;  -- Giorgio Merco nell'ambiente di sviluppo attuale

-- 3) Bug pre-esistente nello schema `task`, SCOPERTO in questa sessione mentre si
--    implementava la creazione task per il TeamLeader: id_task non era AUTO_INCREMENT
--    e `dipendenze` era NOT NULL senza default e senza essere mai popolata dal
--    backend (il campo non è nemmeno mappato in models/Attivita.java). Risultato:
--    POST /attivita/crea non ha MAI funzionato, in nessuna versione precedente
--    dell'app, indipendentemente dalle modifiche di questa sessione.
ALTER TABLE task MODIFY id_task BIGINT NOT NULL AUTO_INCREMENT;
ALTER TABLE task AUTO_INCREMENT = 15;  -- o MAX(id_task)+1 nel tuo ambiente
ALTER TABLE task MODIFY dipendenze VARCHAR(50) NOT NULL DEFAULT '';
```

Punto 3 non è collegato al login/ruoli in sé, ma è stato necessario per far funzionare la creazione dei task da parte di Admin/TeamLeader — senza questo fix ogni `POST /attivita/crea` falliva con `500 Internal Server Error`.

## Nota operativa: ricompilazione manuale in questo ambiente

In questa sessione, senza un runner Gradle disponibile, il backend è stato ricompilato con `javac` diretto puntando alla cache dei jar di Gradle. È stato necessario aggiungere il flag `-parameters`: senza di esso, gli endpoint con `@PathVariable` senza nome esplicito (es. `AssociatoController`/`AssegnatoController`, che usano `@PathVariable Long id` invece di `@PathVariable("id") Long id`) rispondevano con un errore fuorviante ("parameter name information not available via reflection") invece del normale comportamento. Con una build Gradle standard (il plugin Spring Boot imposta `-parameters` di default) questo non si presenta; lo si segnala solo perché è stata la causa di un paio di 400 apparentemente incoerenti durante i test.
