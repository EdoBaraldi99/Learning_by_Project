const Session = (() => {
    'use strict';

    const STORAGE_KEY = 'currentUser';

    function getUser() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch {
            return null;
        }
    }

    function setUser(user) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    }

    function requireLogin() {
        const user = getUser();
        if (!user) {
            location.href = 'login.html';
            return null;
        }
        return user;
    }

    function logout() {
        localStorage.removeItem(STORAGE_KEY);
        location.href = 'login.html';
    }

    // Un utente ha "poteri di gestione" (vede la pagina Utenti, in sola lettura se
    // non admin) se è amministratore globale oppure Capoprogetto su almeno un
    // progetto (Associato.ruolo diverso da "Dipendente").
    async function isManager() {
        const user = getUser();
        if (!user) return false;
        if (user.isAdmin) return true;
        try {
            const res = await fetch(`/associati/dipendente/${user.idDipendente}`);
            if (!res.ok) return false;
            const associati = await res.json();
            return associati.some(a => (a.ruolo || '').toLowerCase() !== 'dipendente');
        } catch {
            return false;
        }
    }

    return { getUser, setUser, requireLogin, logout, isManager };
})();
