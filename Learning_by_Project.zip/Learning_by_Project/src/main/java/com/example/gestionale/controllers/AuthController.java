package com.example.gestionale.controllers;

import com.example.gestionale.dto.DipendenteResponseDTO;
import com.example.gestionale.dto.LoginRequestDTO;
import com.example.gestionale.services.DipendenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    public DipendenteService dipendenteService;

    @PostMapping("/login")
    public ResponseEntity<DipendenteResponseDTO> login(@RequestBody LoginRequestDTO login) {
        return ResponseEntity.ok(dipendenteService.login(login));
    }
}
